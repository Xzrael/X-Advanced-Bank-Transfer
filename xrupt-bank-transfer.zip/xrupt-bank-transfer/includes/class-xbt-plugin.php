<?php
/**
 * Main plugin class.
 *
 * @package X_Bank_Transfer
 */

defined( 'ABSPATH' ) || exit;

/**
 * XBT_Plugin - bootstraps and wires every component.
 */
final class XBT_Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var XBT_Plugin|null
	 */
	private static $instance = null;

	/**
	 * Get the singleton instance.
	 *
	 * @return XBT_Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor. Registers all hooks.
	 */
	private function __construct() {
		$this->includes();
		$this->init_hooks();
	}

	/**
	 * Load required files.
	 */
	private function includes() {
		require_once XBT_PLUGIN_DIR . 'includes/class-xbt-gateway.php';
		require_once XBT_PLUGIN_DIR . 'includes/class-xbt-upload-handler.php';
	}

	/**
	 * Register hooks.
	 */
	private function init_hooks() {
		add_filter( 'woocommerce_payment_gateways', array( $this, 'add_gateway' ) );

		// Load text domain for translations.
		add_action( 'init', array( $this, 'load_textdomain' ) );

		// Register the receipt upload AJAX endpoints (works for guests too).
		add_action( 'wp_ajax_xbt_upload_receipt', array( 'XBT_Upload_Handler', 'handle_upload' ) );
		add_action( 'wp_ajax_nopriv_xbt_upload_receipt', array( 'XBT_Upload_Handler', 'handle_upload' ) );

		// Enqueue frontend assets for the checkout upload field.
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );

		// Add a settings link on the plugins screen.
		add_filter( 'plugin_action_links_' . XBT_PLUGIN_BASENAME, array( $this, 'plugin_action_links' ) );

		// Display the uploaded receipt on the admin order edit screen.
		add_action( 'woocommerce_admin_order_data_after_billing_address', array( $this, 'display_receipt_in_admin' ) );

		// Customer facing styled receipt: thank you + My Account view order + order details.
		add_action( 'woocommerce_thankyou', array( $this, 'display_receipt_on_thankyou' ), 20 );
		add_action( 'woocommerce_view_order', array( $this, 'display_receipt_on_frontend' ), 20 );
		add_action( 'woocommerce_order_details_after_order_table', array( $this, 'display_receipt_on_frontend' ), 10 );

		// Admin + frontend lightbox assets.
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
		add_action( 'wp_footer', array( $this, 'render_lightbox_markup' ) );
		add_action( 'admin_footer', array( $this, 'render_lightbox_markup' ) );
	}

	/**
	 * Add the gateway to the list of available WooCommerce gateways.
	 *
	 * @param array $gateways Existing gateways.
	 * @return array
	 */
	public function add_gateway( $gateways ) {
		$gateways[] = 'XBT_Gateway';
		return $gateways;
	}

	/**
	 * Load the plugin text domain.
	 */
	public function load_textdomain() {
		load_plugin_textdomain( 'xrupt-bank-transfer', false, dirname( XBT_PLUGIN_BASENAME ) . '/languages' );
	}

	/**
	 * Register frontend assets.
	 */
	public function register_assets() {
		if ( ! function_exists( 'is_checkout' ) ) {
			return;
		}
		$load = false;
		if ( is_checkout() ) {
			$load = true;
		}
		if ( function_exists( 'is_order_received_page' ) && is_order_received_page() ) {
			$load = true;
		}
		if ( function_exists( 'is_account_page' ) && is_account_page() ) {
			$load = true;
		}
		if ( function_exists( 'is_view_order_page' ) && is_view_order_page() ) {
			$load = true;
		}
		if ( function_exists( 'is_wc_endpoint_url' ) && ( is_wc_endpoint_url( 'view-order' ) || is_wc_endpoint_url( 'order-received' ) ) ) {
			$load = true;
		}
		if ( ! $load ) {
			return;
		}

		wp_register_style( 'xbt-checkout', XBT_PLUGIN_URL . 'assets/css/xbt-checkout.css', array(), XBT_VERSION );
		wp_enqueue_style( 'xbt-checkout' );

		// Inject the configured colors as CSS variables so the stylesheet
		// can be re-themed entirely from the gateway settings.
		$styling = self::get_styling_config();
		$inline  = ':root{'
			. '--xbt-primary:#' . esc_attr( ltrim( $styling['primary'], '#' ) ) . ';'
			. '--xbt-accent:#' . esc_attr( ltrim( $styling['accent'], '#' ) ) . ';'
			. '--xbt-primary-soft:' . esc_attr( self::hex_to_rgba( $styling['primary'], 0.06 ) ) . ';'
			. '--xbt-accent-soft:' . esc_attr( self::hex_to_rgba( $styling['accent'], 0.10 ) ) . ';'
			. '--xbt-primary-border:' . esc_attr( self::hex_to_rgba( $styling['primary'], 0.15 ) ) . ';'
			. '--xbt-primary-border-strong:' . esc_attr( self::hex_to_rgba( $styling['primary'], 0.25 ) ) . ';'
			. '--xbt-primary-dashed:' . esc_attr( self::hex_to_rgba( $styling['primary'], 0.35 ) ) . ';'
			. '--xbt-primary-shadow:' . esc_attr( self::hex_to_rgba( $styling['primary'], 0.08 ) ) . ';'
			. '--xbt-primary-shadow-soft:' . esc_attr( self::hex_to_rgba( $styling['primary'], 0.04 ) ) . ';'
			. '--xbt-primary-darker:' . esc_attr( self::darken_hex( $styling['primary'] ) ) . ';'
			. '}';
		wp_add_inline_style( 'xbt-checkout', $inline );

		wp_register_script( 'xbt-checkout-script', XBT_PLUGIN_URL . 'assets/js/xbt-checkout.js', array( 'jquery' ), XBT_VERSION, true );

		wp_localize_script(
			'xbt-checkout-script',
			'xbtCheckout',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'xbt_upload_receipt' ),
				'text'    => array(
					'invalidFile' => __( 'Invalid file type. Please upload a JPG, PNG or PDF file.', 'xrupt-bank-transfer' ),
					'defaultError' => __( 'There was an error uploading the file. Please try again.', 'xrupt-bank-transfer' ),
				),
			)
		);

		wp_enqueue_script( 'xbt-checkout-script' );
	}

	/**
	 * Add a "Settings" link to the plugin row on the Plugins screen.
	 *
	 * @param array $links Action links for the plugin.
	 * @return array
	 */
	public function plugin_action_links( $links ) {
		$settings_url = admin_url( 'admin.php?page=wc-settings&tab=checkout&section=xbt_gateway' );

		$plugin_links = array(
			'<a href="' . esc_url( $settings_url ) . '">' . esc_html__( 'Settings', 'xrupt-bank-transfer' ) . '</a>',
		);

		return array_merge( $plugin_links, $links );
	}

	/**
	 * Display the uploaded bank receipt on the admin order edit screen - styled + lightbox.
	 *
	 * @param WC_Order $order Order object.
	 */
	public function display_receipt_in_admin( $order ) {
		if ( ! $order instanceof WC_Order ) {
			return;
		}
		if ( $this->gateway_id() !== $order->get_payment_method() ) {
			return;
		}
		$attach_id = $order->get_meta( '_xbt_receipt_attachment_id' );
		if ( empty( $attach_id ) || 'attachment' !== get_post_type( $attach_id ) ) {
			return;
		}
		$src = wp_get_attachment_url( $attach_id );
		if ( ! $src ) {
			return;
		}
		echo '<div class="xbt-admin-receipt">';
		$this->render_receipt_card( $attach_id, $src, true );
		echo '</div>';
	}

	/**
	 * Frontend: thank you page (order received) - styled receipt below order details.
	 *
	 * @param int $order_id Order ID.
	 */
	public function display_receipt_on_thankyou( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order || $this->gateway_id() !== $order->get_payment_method() ) {
			return;
		}
		$attach_id = $order->get_meta( '_xbt_receipt_attachment_id' );
		if ( empty( $attach_id ) || 'attachment' !== get_post_type( $attach_id ) ) {
			return;
		}
		$src = wp_get_attachment_url( $attach_id );
		if ( ! $src ) {
			return;
		}
		echo '<div class="xbt-thankyou-receipt" style="margin: 24px 0;">';
		$this->render_receipt_card( $attach_id, $src, false );
		echo '</div>';
	}

	/**
	 * Frontend: view order / order details - styled receipt.
	 *
	 * @param WC_Order|int $order Order or ID.
	 */
	public function display_receipt_on_frontend( $order ) {
		if ( is_int( $order ) ) {
			$order = wc_get_order( $order );
		}
		if ( ! $order instanceof WC_Order || $this->gateway_id() !== $order->get_payment_method() ) {
			return;
		}
		// Avoid double output on thankyou (thankyou already handled).
		if ( doing_action( 'woocommerce_thankyou' ) ) {
			return;
		}
		$attach_id = $order->get_meta( '_xbt_receipt_attachment_id' );
		if ( empty( $attach_id ) || 'attachment' !== get_post_type( $attach_id ) ) {
			return;
		}
		$src = wp_get_attachment_url( $attach_id );
		if ( ! $src ) {
			return;
		}
		$this->render_receipt_card( $attach_id, $src, false );
	}

	/**
	 * Render the unified styled receipt card (uses CSS variables from Checkout styling).
	 *
	 * @param int    $attach_id Attachment ID.
	 * @param string $src       File URL.
	 * @param bool   $is_admin  Admin context.
	 */
	private function render_receipt_card( $attach_id, $src, $is_admin = false ) {
		$mime     = get_post_mime_type( $attach_id );
		$title    = get_the_title( $attach_id );
		$filename = basename( get_attached_file( $attach_id ) ?: $src );
		$is_image = $mime && 0 === strpos( $mime, 'image/' );
		$label    = $is_image ? __( 'Image receipt', 'xrupt-bank-transfer' ) : __( 'PDF receipt', 'xrupt-bank-transfer' );
		$thumb    = $is_image ? wp_get_attachment_image_url( $attach_id, 'medium' ) : '';
		if ( ! $thumb ) {
			$thumb = $src;
		}
		?>
		<div class="xbt-receipt-card">
			<div class="xbt-receipt-card__head">
				<h3 class="xbt-receipt-card__title"><?php esc_html_e( 'Bank Payment Receipt', 'xrupt-bank-transfer' ); ?></h3>
				<span class="xbt-receipt-card__badge"><?php echo esc_html( $label ); ?></span>
			</div>
			<div class="xbt-receipt-card__preview">
				<?php if ( $is_image ) : ?>
					<img class="xbt-receipt-card__thumb xbt-js-preview" src="<?php echo esc_url( $thumb ); ?>" data-src="<?php echo esc_url( $src ); ?>" data-title="<?php echo esc_attr( $title ?: $filename ); ?>" alt="<?php echo esc_attr( $title ?: $filename ); ?>" loading="lazy" />
				<?php else : ?>
					<div class="xbt-receipt-card__thumb" style="display:flex;align-items:center;justify-content:center;background:var(--xbt-primary-soft);border-style:dashed;font-size:22px;">PDF</div>
				<?php endif; ?>
				<div class="xbt-receipt-card__meta">
					<div class="xbt-receipt-card__filename" title="<?php echo esc_attr( $filename ); ?>"><?php echo esc_html( $filename ); ?></div>
					<div class="xbt-receipt-card__hint"><?php $is_image ? esc_html_e( 'Click image to preview. Tap outside or press Esc to close.', 'xrupt-bank-transfer' ) : esc_html_e( 'PDF will open in a new tab.', 'xrupt-bank-transfer' ); ?></div>
					<div class="xbt-receipt-actions">
						<?php if ( $is_image ) : ?>
							<a href="#" class="xbt-btn xbt-btn--primary xbt-js-preview" data-src="<?php echo esc_url( $src ); ?>" data-title="<?php echo esc_attr( $title ?: $filename ); ?>"><?php esc_html_e( 'Preview', 'xrupt-bank-transfer' ); ?></a>
						<?php endif; ?>
						<a href="<?php echo esc_url( $src ); ?>" target="_blank" rel="noopener" class="xbt-btn <?php echo $is_image ? 'xbt-btn--ghost' : 'xbt-btn--primary'; ?>" download><?php $is_image ? esc_html_e( 'Download', 'xrupt-bank-transfer' ) : esc_html_e( 'View / Download PDF', 'xrupt-bank-transfer' ); ?></a>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Enqueue admin assets for order screen (same CSS variables for brand consistency).
	 *
	 * @param string $hook Hook suffix.
	 */
	public function enqueue_admin_assets( $hook ) {
		if ( 'post.php' !== $hook && 'woocommerce_page_wc-orders' !== $hook ) {
			// Still allow on HPOS order edit.
			$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
			if ( ! $screen || false === strpos( $screen->id ?? '', 'shop_order' ) ) {
				return;
			}
		}
		wp_enqueue_style( 'xbt-checkout', XBT_PLUGIN_URL . 'assets/css/xbt-checkout.css', array(), XBT_VERSION );
		$styling = self::get_styling_config();
		$inline  = ':root{'
			. '--xbt-primary:#' . esc_attr( ltrim( $styling['primary'], '#' ) ) . ';'
			. '--xbt-accent:#' . esc_attr( ltrim( $styling['accent'], '#' ) ) . ';'
			. '--xbt-primary-soft:' . esc_attr( self::hex_to_rgba( $styling['primary'], 0.06 ) ) . ';'
			. '--xbt-accent-soft:' . esc_attr( self::hex_to_rgba( $styling['accent'], 0.10 ) ) . ';'
			. '--xbt-primary-border:' . esc_attr( self::hex_to_rgba( $styling['primary'], 0.15 ) ) . ';'
			. '--xbt-primary-border-strong:' . esc_attr( self::hex_to_rgba( $styling['primary'], 0.25 ) ) . ';'
			. '--xbt-primary-dashed:' . esc_attr( self::hex_to_rgba( $styling['primary'], 0.35 ) ) . ';'
			. '--xbt-primary-shadow:' . esc_attr( self::hex_to_rgba( $styling['primary'], 0.08 ) ) . ';'
			. '--xbt-primary-shadow-soft:' . esc_attr( self::hex_to_rgba( $styling['primary'], 0.04 ) ) . ';'
			. '--xbt-primary-darker:' . esc_attr( self::darken_hex( $styling['primary'] ) ) . ';'
			. '}';
		wp_add_inline_style( 'xbt-checkout', $inline );
		wp_enqueue_script( 'xbt-checkout-script', XBT_PLUGIN_URL . 'assets/js/xbt-checkout.js', array( 'jquery' ), XBT_VERSION, true );
	}

	/**
	 * Lightbox markup (shared frontend + admin) - uses CSS variables, no raw directory links exposed as plain text.
	 * Only rendered on order-related screens to avoid footer bleed.
	 */
	public function render_lightbox_markup() {
		static $done = false;
		if ( $done ) {
			return;
		}
		// Only on checkout / order-received / view-order / my-account or admin shop_order screens.
		$should = false;
		if ( is_admin() ) {
			$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
			if ( $screen && false !== strpos( $screen->id ?? '', 'shop_order' ) ) {
				$should = true;
			}
			if ( isset( $_GET['page'] ) && 'wc-orders' === $_GET['page'] ) {
				$should = true;
			}
		} else {
			if ( function_exists( 'is_checkout' ) && is_checkout() ) {
				$should = true;
			}
			if ( function_exists( 'is_account_page' ) && is_account_page() ) {
				$should = true;
			}
			if ( function_exists( 'is_view_order_page' ) && is_view_order_page() ) {
				$should = true;
			}
			if ( function_exists( 'is_order_received_page' ) && is_order_received_page() ) {
				$should = true;
			}
			if ( function_exists( 'is_wc_endpoint_url' ) && ( is_wc_endpoint_url( 'view-order' ) || is_wc_endpoint_url( 'order-received' ) ) ) {
				$should = true;
			}
		}
		if ( ! $should ) {
			return;
		}
		$done = true;
		?>
		<div id="xbt-receipt-modal" class="xbt-modal" aria-hidden="true" role="dialog" aria-modal="true" style="display:none">
			<div class="xbt-modal__backdrop xbt-js-modal-close"></div>
			<div class="xbt-modal__dialog" role="document">
				<div class="xbt-modal__bar">
					<h4 class="xbt-modal__title"><?php esc_html_e( 'Payment Receipt', 'xrupt-bank-transfer' ); ?></h4>
					<button type="button" class="xbt-modal__close xbt-js-modal-close" aria-label="<?php esc_attr_e( 'Close', 'xrupt-bank-transfer' ); ?>">×</button>
				</div>
				<div class="xbt-modal__body"><img src="" alt="" /></div>
				<div class="xbt-modal__actions">
					<a href="#" target="_blank" rel="noopener" class="xbt-btn xbt-btn--primary xbt-modal__download" download><?php esc_html_e( 'Download', 'xrupt-bank-transfer' ); ?></a>
					<button type="button" class="xbt-btn xbt-btn--ghost xbt-js-modal-close"><?php esc_html_e( 'Close', 'xrupt-bank-transfer' ); ?></button>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Get the payment gateway ID used by this plugin.
	 *
	 * @return string
	 */
	private function gateway_id() {
		return 'xbt_gateway';
	}

	/**
	 * Build the styling configuration from saved settings.
	 *
	 * In "theme" mode the primary/accent colors are read from the active
	 * theme (Customizer mods first, then block-theme palette) and fall back
	 * to the manual colors when nothing is found. In "manual" mode the saved
	 * custom colors are used. All return values are validated hex colors.
	 *
	 * @return array{source:string, primary:string, accent:string}
	 */
	public static function get_styling_config() {
		$defaults = array(
			'source'  => 'manual',
			'primary' => '#9804CC',
			'accent'  => '#FFBE56',
		);

		// WooCommerce stores all gateway settings in one option array.
		$all_settings = get_option( 'woocommerce_xbt_gateway_settings', array() );
		$all_settings = is_array( $all_settings ) ? $all_settings : array();
		$settings     = isset( $all_settings['styling'] ) && is_array( $all_settings['styling'] ) ? $all_settings['styling'] : array();
		$config       = wp_parse_args( $settings, $defaults );

		$primary = self::sanitize_hex_color( isset( $config['primary'] ) ? $config['primary'] : '' );
		$accent  = self::sanitize_hex_color( isset( $config['accent'] ) ? $config['accent'] : '' );

		if ( 'theme' === $config['source'] ) {
			$theme_primary = self::theme_color( 'primary' );
			$theme_accent  = self::theme_color( 'accent' );

			if ( $theme_primary ) {
				$primary = $theme_primary;
			}
			if ( $theme_accent ) {
				$accent = $theme_accent;
			}
		}

		return array(
			'source'  => 'theme' === $config['source'] ? 'theme' : 'manual',
			'primary' => $primary ? $primary : $defaults['primary'],
			'accent'  => $accent ? $accent : $defaults['accent'],
		);
	}

	/**
	 * Try to read a color (primary/accent) from the active theme.
	 *
	 * @param string $role 'primary' or 'accent'.
	 * @return string Validated hex color or empty string.
	 */
	public static function theme_color( $role ) {
		// Let other plugins/themes override detection entirely.
		$filtered = apply_filters( "xbt_theme_{$role}_color", '', $role );
		$color    = self::sanitize_hex_color( $filtered );
		if ( $color ) {
			return $color;
		}

		// Common Customizer theme mods.
		$mods = 'primary' === $role
			? array( 'primary_color', 'primary', 'theme_color', 'xbt_primary' )
			: array( 'accent_color', 'accent', 'secondary_color', 'xbt_accent' );

		foreach ( $mods as $mod ) {
			$value = get_theme_mod( $mod, '' );
			$color = self::sanitize_hex_color( $value );
			if ( $color ) {
				return $color;
			}
		}

		// Block themes expose their palette via global styles settings (WP 5.9+).
		if ( function_exists( 'wp_get_global_settings' ) ) {
			$palette = wp_get_global_settings( array( 'color', 'palette' ) );
			if ( is_array( $palette ) ) {
				// Palette may be grouped per theme: ['theme' => [...], 'default' => [...]].
				$slugs = 'primary' === $role ? array( 'primary' ) : array( 'accent', 'secondary' );
				$listed = self::find_palette_color( $palette, $slugs );
				if ( $listed ) {
					$color = self::sanitize_hex_color( $listed );
					if ( $color ) {
						return $color;
					}
				}
			}
		}

		return '';
	}

	/**
	 * Search a theme.json palette array for the first matching slug color.
	 *
	 * @param mixed  $palette Palette data.
	 * @param array  $slugs   Slugs to look for.
	 * @return string
	 */
	private static function find_palette_color( $palette, $slugs ) {
		if ( ! is_array( $palette ) || empty( $slugs ) ) {
			return '';
		}

		foreach ( $slugs as $slug ) {
			$found = self::search_slug( $palette, $slug );
			if ( $found ) {
				return $found;
			}
		}

		return '';
	}

	/**
	 * Recursively search palette entries for a slug and return its color.
	 *
	 * @param mixed  $items Array to search.
	 * @param string $slug  Slug to find.
	 * @return string
	 */
	private static function search_slug( $items, $slug ) {
		if ( ! is_array( $items ) ) {
			return '';
		}

		foreach ( $items as $key => $item ) {
			if ( 'slug' === $key && $item === $slug && isset( $items['color'] ) ) {
				return $items['color'];
			}
			if ( is_array( $item ) ) {
				$result = self::search_slug( $item, $slug );
				if ( $result ) {
					return $result;
				}
			}
		}

		return '';
	}

	/**
	 * Sanitize a hex color robustly (works even when sanitize_hex_color is
	 * not loaded).
	 *
	 * @param string $color Raw color value.
	 * @return string|false Validated "#rrggbb" or "#rgb" hex, or false.
	 */
	public static function sanitize_hex_color( $color ) {
		if ( is_string( $color ) && preg_match( '/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $color ) ) {
			return $color;
		}
		return '';
	}

	/**
	 * Convert a hex color to an rgba() string.
	 *
	 * @param string $hex Hex color.
	 * @param float  $alpha Alpha 0-1.
	 * @return string
	 */
	public static function hex_to_rgba( $hex, $alpha = 1 ) {
		$hex  = ltrim( self::sanitize_hex_color( $hex ), '#' );
		$alpha = max( 0, min( 1, (float) $alpha ) );

		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		if ( 6 !== strlen( $hex ) ) {
			$hex = '9804CC';
		}

		$r = hexdec( substr( $hex, 0, 2 ) );
		$g = hexdec( substr( $hex, 2, 2 ) );
		$b = hexdec( substr( $hex, 4, 2 ) );

		return 'rgba(' . $r . ',' . $g . ',' . $b . ',' . $alpha . ')';
	}

	/**
	 * Return a slightly darkened version of a hex color (used for hover states).
	 *
	 * @param string $hex Hex color.
	 * @return string
	 */
	public static function darken_hex( $hex, $factor = 0.12 ) {
		$hex = ltrim( self::sanitize_hex_color( $hex ), '#' );

		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		if ( 6 !== strlen( $hex ) ) {
			$hex = '9804CC';
		}

		$r = max( 0, (int) ( hexdec( substr( $hex, 0, 2 ) ) * ( 1 - $factor ) ) );
		$g = max( 0, (int) ( hexdec( substr( $hex, 2, 2 ) ) * ( 1 - $factor ) ) );
		$b = max( 0, (int) ( hexdec( substr( $hex, 4, 2 ) ) * ( 1 - $factor ) ) );

		return sprintf( '#%02x%02x%02x', $r, $g, $b );
	}
}
