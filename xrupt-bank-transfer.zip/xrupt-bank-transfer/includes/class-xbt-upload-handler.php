<?php
/**
 * AJAX receipt upload handler.
 *
 * @package X_Bank_Transfer
 */

defined( 'ABSPATH' ) || exit;

/**
 * XBT_Upload_Handler - handles the checkout receipt upload via AJAX.
 */
class XBT_Upload_Handler {

	/**
	 * Handle the AJAX upload request.
	 */
	public static function handle_upload() {
		// Verify the nonce (CSRF protection). Nonce is created in XBT_Plugin::register_assets().
		check_ajax_referer( 'xbt_upload_receipt', 'nonce' );

		// No file uploaded.
		if ( empty( $_FILES['file'] ) || empty( $_FILES['file']['name'] ) ) {
			wp_send_json_error( array( 'message' => __( 'No file was uploaded.', 'xrupt-bank-transfer' ) ) );
		}

		// 5 MB hard limit (still respects WordPress upload_max_filesize via wp_handle_upload).
		$max_size = 5 * 1024 * 1024;
		if ( isset( $_FILES['file']['size'] ) && (int) $_FILES['file']['size'] > $max_size ) {
			wp_send_json_error( array( 'message' => __( 'File is too large. Maximum size is 5 MB.', 'xrupt-bank-transfer' ) ) );
		}

		$filename  = sanitize_file_name( wp_unslash( $_FILES['file']['name'] ) );
		$extension = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );

		// Supported file types (filterable).
		$valid_formats = apply_filters( 'xbt_allowed_receipt_types', array( 'jpg', 'jpeg', 'png', 'pdf' ) );

		if ( ! in_array( $extension, $valid_formats, true ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid file type. Please upload a JPG, PNG or PDF file.', 'xrupt-bank-transfer' ) ) );
		}

		// Load WordPress upload helpers.
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$upload_overrides = array( 'test_form' => false );

		$movefile = wp_handle_upload( $_FILES['file'], $upload_overrides );

		if ( isset( $movefile['error'] ) ) {
			wp_send_json_error( array( 'message' => $movefile['error'] ) );
		}

		if ( empty( $movefile['file'] ) || empty( $movefile['url'] ) ) {
			wp_send_json_error( array( 'message' => __( 'There was an error uploading the file.', 'xrupt-bank-transfer' ) ) );
		}

		// Verify MIME type server-side (extension alone is not sufficient).
		$allowed_mimes = array(
			'jpg|jpeg' => 'image/jpeg',
			'png'      => 'image/png',
			'pdf'      => 'application/pdf',
		);
		$filetype = wp_check_filetype( basename( $movefile['file'] ), $allowed_mimes );

		if ( empty( $filetype['type'] ) || ! in_array( $filetype['type'], array( 'image/jpeg', 'image/png', 'application/pdf' ), true ) ) {
			// Remove the file that failed MIME check.
			if ( ! empty( $movefile['file'] ) && file_exists( $movefile['file'] ) ) {
				unlink( $movefile['file'] ); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.file_ops_unlink
			}
			wp_send_json_error( array( 'message' => __( 'Invalid file type. Please upload a JPG, PNG or PDF file.', 'xrupt-bank-transfer' ) ) );
		}

		$attachment = array(
			'guid'           => $movefile['url'],
			'post_mime_type' => $filetype['type'],
			'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $movefile['file'] ) ),
			'post_content'   => '',
			'post_status'    => 'inherit',
		);

		// Insert the attachment and generate metadata.
		$attach_id = wp_insert_attachment( $attachment, $movefile['file'] );

		if ( is_wp_error( $attach_id ) || ! $attach_id ) {
			if ( file_exists( $movefile['file'] ) ) {
				unlink( $movefile['file'] ); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.file_ops_unlink
			}
			$message = is_wp_error( $attach_id ) ? $attach_id->get_error_message() : __( 'There was an error saving the receipt.', 'xrupt-bank-transfer' );
			wp_send_json_error( array( 'message' => $message ) );
		}

		$attach_data = wp_generate_attachment_metadata( $attach_id, $movefile['file'] );
		wp_update_attachment_metadata( $attach_id, $attach_data );

		// Tag the attachment so it can be cleaned up reliably on uninstall.
		update_post_meta( $attach_id, '_xbt_receipt', '1' );

		// Return the attachment ID as the success payload.
		wp_send_json_success( $attach_id );
	}
}
